###
###   Field 1 = root directory
###   Field 2 = folder to be read
###   Field 3 = direction of ls
###
###
./collect.sh Shared/Photos/Family Pixie -l
#./collect.sh Shared/Photos/Places/Europe/EU-CH-Switzerland EU-CH-Matterhorn -l
