#!/bin/bash

# echo $RANDOM % 10 + 1 | bc
# grep -m1 -ao '[0-9]' /dev/urandom | sed s/0/10/ | head -n1


#NETPBM=/opt/set-1.1/netpbm/bin
NETPBM=/usr/bin

PHOTOPATH=$1
FOLDER=$2
# can be -ltr or -lr
LIST_DIRECTION=$3

APP_HOME=/opt/gallery.app
CONF_HOME=$APP_HOME/conf
GALLERY_XML=$APP_HOME/xmlfiles
IMAGES=$APP_HOME/images
METADATA=$APP_HOME/metadata
PHOTO_SOURCE=/var/opt


CLASSPATH=/opt/java/custom-java
JAVA=/opt/java/jre-9.0.1/bin/java

EXTRACT_DATA=/opt/java/custom-java/UTIL_ExtractEXIF_v1.2_9.0.1.jar 
#EXTRACT_DATA=/opt/java/custom-java/UTIL_ExtractEXIF_v1.2_9.0.1.jar
EXIFTOOL=/opt/perl/Image-ExifTool-10.02/exiftool
FORMATMETA=/opt/java/custom-java/UTIL_FormatEXIFMetaDataToHTML_v1.2_9.0.1.jar



##############################################################
### Setup the files
##############################################################
SETUP() {

   echo "Path = $PHOTOPATH,  Folder = $FOLDER"
   FOLDERTITLE=`echo $FOLDER | sed 's/_/ /g'`

   touch $FOLDER.xml
   echo "<tomcat_photo_gallery title=\"$FOLDERTITLE\"" > $FOLDER.xml
   echo "     dir_thumbnails=\"images/thumbnails/$FOLDER\"" >> $FOLDER.xml
   echo "     dir_web=\"images/folders/$FOLDER\"" >> $FOLDER.xml
   echo "     dir_originals=\"$PHOTOPATH/$FOLDER\"" >> $FOLDER.xml
   echo "     thumbnailsPerRow=\"4\"" >> $FOLDER.xml
   echo "     thumbnailColumnWidth=\"180\">" >> $FOLDER.xml
   echo " " >> $FOLDER.xml
   echo " " >> $FOLDER.xml


   touch load_$FOLDER.xml.sql
   echo "delete from gallery where xml_file='$FOLDER.xml';" > load_$FOLDER.xml.sql
   echo "commit;" >> load_$FOLDER.xml.sql

   rm -r $IMAGES/thumbnails/$FOLDER
   rm -r $IMAGES/folders/$FOLDER

   mkdir $IMAGES/thumbnails/$FOLDER
   mkdir $IMAGES/folders/$FOLDER

   chmod 755 $IMAGES/thumbnails/$FOLDER
   chmod 755 $IMAGES/folders/$FOLDER


   rm /tmp/$FOLDER.txt

   REDUCE_PMM=$REDUCE_PMM.$$
   REDUCE_3_PMM=/tmp/reduce_3.pmm.$$
   REDUCE_12_PMM=/tmp/reduce_12.pmm.$$



echo "*******************************"
   ls $LIST_DIRECTION $PHOTO_SOURCE/$PHOTOPATH/$FOLDER | grep -i jpg | awk '{print $5 "," $9}'> /tmp/$FOLDER.txt

   READ_FILE=`cat /tmp/$FOLDER.txt `

   ##create directory for exip xml information

	
   rm -r $METADATA/$FOLDER
   mkdir $METADATA/$FOLDER
   chmod 755 $METADATA/$FOLDER

}


##############################################################
### Reduce the image
##############################################################
REDUCE_IMAGE() {
   #if file < 100, then just copy over
   #else if < 500, then only thumbnail reduction 
   #else do full reduction

   echo "   reduce image"

   if [ $SIZE -lt 100000 ] ; then
	echo $SIZE " : no reduction"
	cp $HIGHRES_PHOTO $IMAGES/folders/$FOLDER/$NAME.$EXT
	cp $HIGHRES_PHOTO $IMAGES/thumbnails/$FOLDER/$NAME-thumb.$EXT
   else
	if [ $SIZE -lt 400000 ] ; then
		echo $SIZE " : less than 500"
		#create the smaller image files
		cp $PHOTO_SOURCE/$PHOTOPATH/$FOLDER/$NAME.$EXT $IMAGES/folders/$FOLDER/$NAME.$EXT

		$NETPBM/jpegtopnm $PHOTO_SOURCE/$PHOTOPATH/$FOLDER/$NAME.$EXT > $REDUCE_PMM
		
		$NETPBM/pnmscalefixed -reduce 5 $REDUCE_PMM > $REDUCE_12_PMM
		
		$NETPBM/pnmtojpeg $REDUCE_12_PMM > $IMAGES/thumbnails/$FOLDER/$NAME-thumb.$EXT
	else
		echo $SIZE " : regular reduction"
		
		#create the smaller image files
		$NETPBM/jpegtopnm $PHOTO_SOURCE/$PHOTOPATH/$FOLDER/$NAME.$EXT > $REDUCE_PMM
		
		$NETPBM/pnmscalefixed -reduce 2 $REDUCE_PMM > $REDUCE_3_PMM
		$NETPBM/pnmscalefixed -reduce 12 $REDUCE_PMM > $REDUCE_12_PMM
		
		$NETPBM/pnmtojpeg $REDUCE_3_PMM > $IMAGES/folders/$FOLDER/$NAME.$EXT
		$NETPBM/pnmtojpeg $REDUCE_12_PMM > $IMAGES/thumbnails/$FOLDER/$NAME-thumb.$EXT
		
	fi
   fi

   chmod 755 $IMAGES/folders/$FOLDER/$NAME.$EXT
   chmod 755 $IMAGES/thumbnails/$FOLDER/$NAME-thumb.$EXT
}


##############################################################
### Get exif info
##############################################################
GET_EXIF(){
   echo "   Get EXIF"
   $JAVA -jar $EXTRACT_DATA meta $HIGHRES_PHOTO > $METADATA/$FOLDER/$NAME.$EXT.meta.xml 
}


##############################################################
### copy random thumbnail to marquee
##############################################################
CREATE_MARQUEE_PHOTO(){
   RANDOM_FILE=`$JAVA -jar $EXTRACT_DATA marquee $IMAGES/thumbnails/$FOLDER`
   echo "   Creating marquee photo: " $RANDOM_FILE " : " $FOLDER
   cp $IMAGES/thumbnails/$FOLDER/$RANDOM_FILE $IMAGES/marquee/marquee_$FOLDER.xml.jpg
}


##############################################################
### transfer exif data
##############################################################
COPY_EXIF(){
# copy exif from orig
# usage:  exiftool -tagsfromfile source_file -all:all -overwrite_original dest_file
   echo "   EXIF transfer: $PHOTO_SOURCE/$PHOTOPATH/$FOLDER/$NAME.$EXT "
$EXIFTOOL -tagsfromfile $PHOTO_SOURCE/$PHOTOPATH/$FOLDER/$NAME.$EXT -all:all -overwrite_original $IMAGES/folders/$FOLDER/$NAME.$EXT
}

##############################################################
### insert sql statement
##############################################################
INSERT_SQL_STATEMENT(){
   LOWERCASE=`$JAVA -jar $EXTRACT_DATA toLowercase $NAME.$EXT`
   echo "INSERT INTO gallery VALUES ('$LOWERCASE','$FOLDER.xml');" >> load_$FOLDER.xml.sql
   echo "   SQL insert created"
}



##############################################################
### extra metadata and format for web viewing
##############################################################
DUMP_FORMAT_EXIF_FOR_WEB(){
echo "*** dump exif for schema... ***"
EXIFTOOL_XML=$METADATA/$FOLDER/$NAME.$EXT.exiftool.xml
# copy exif from orig
# usage:  exiftool -X $HIGHRES_PHOTO > $EXIFTOOL_XML
   echo "EXIF dump xml:  $HIGHRES_PHOTO > $EXIFTOOL_XML"
$EXIFTOOL -X $HIGHRES_PHOTO > $EXIFTOOL_XML

   echo "transform xml to: $EXIFTOOL_XML.meta.html.txt"
   $JAVA -jar $FORMATMETA HTMLSchema5 $EXIFTOOL_XML > $EXIFTOOL_XML.meta.html5.txt
   $JAVA -jar $FORMATMETA HTMLDisplay5 $EXIFTOOL_XML >> $EXIFTOOL_XML.meta.html5.txt
   $JAVA -jar $FORMATMETA HTMLDisplay4 $EXIFTOOL_XML gallery_user.property> $EXIFTOOL_XML.meta.html4.txt
}



##############################################################
##############################################################
##############################################################
##############################################################

SETUP

for LINE in $READ_FILE
do
   FILE=`echo $LINE | awk -F, '{print $2}'`
   SIZE=`echo $LINE | awk -F, '{print $1}'`

   NAME=`echo $FILE | awk -F. '{print $1}'`
   EXT=`echo $FILE | awk -F. '{print $2}'`

   echo 
   echo "File:  " $NAME.$EXT

   HIGHRES_PHOTO=$PHOTO_SOURCE/$PHOTOPATH/$FOLDER/$NAME.$EXT 

   echo $JAVA -jar $EXTRACT_DATA title $NAME
   TITLE=`$JAVA -jar $EXTRACT_DATA title $NAME`
   DATE=`$JAVA -jar $EXTRACT_DATA date $NAME`



   echo "<photo title=\"$TITLE\""  >> $FOLDER.xml
   echo "       date=\"$DATE\" "  >> $FOLDER.xml
   echo "       file_thumbnail=\"$NAME-thumb.$EXT\""  >> $FOLDER.xml
   echo "       file_web=\"$NAME.$EXT\""  >> $FOLDER.xml
   echo "       file_original=\"$NAME.$EXT\""  >> $FOLDER.xml
   echo "       file_original_size=\"$SIZE\" />"  >> $FOLDER.xml
   echo " "  >> $FOLDER.xml
   echo " "  >> $FOLDER.xml


   REDUCE_IMAGE
   # GET_EXIF no longer needed
   #GET_EXIF
   COPY_EXIF
   DUMP_FORMAT_EXIF_FOR_WEB
   INSERT_SQL_STATEMENT

       
done

echo "</tomcat_photo_gallery>" >> $FOLDER.xml
echo "COMMIT;" >> load_$FOLDER.xml.sql

mv $FOLDER.xml $GALLERY_XML

CREATE_MARQUEE_PHOTO

rm $REDUCE_PMM $REDUCE_3_PMM $REDUCE_12_PMM



